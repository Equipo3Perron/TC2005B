DELETE Friend
DBCC CHECKIDENT('Usuario', RESEED, 0)


INSERT INTO Friend VALUES(
    2,
    1,
    1,
    0,
    0
)

INSERT INTO Friend VALUES(
    9,
    1,
    1,
    0,
    0
)

INSERT INTO Friend VALUES(
    1,
    3,
    1,
    1,
    1
)

INSERT INTO Friend VALUES(
    3,
    1,
    1,
    1,
    0
)




-- INSERT INTO Friend VALUES(
--     1,
--     8,
--     1,
--     0,
--     0
-- )